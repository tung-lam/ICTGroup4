require 'test_helper'

class Usergame1Test < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
