require 'test_helper'

class Usergame3Test < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
