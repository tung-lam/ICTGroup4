require 'test_helper'

class UserrubyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
