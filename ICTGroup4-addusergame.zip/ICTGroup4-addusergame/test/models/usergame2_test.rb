require 'test_helper'

class Usergame2Test < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
