require 'test_helper'

class Game1ControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
