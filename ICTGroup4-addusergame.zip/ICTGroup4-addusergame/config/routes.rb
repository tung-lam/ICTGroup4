Rails.application.routes.draw do
  
  devise_for :users
<<<<<<< HEAD

  get "/game1" => "game1#index"

 
  get "/pages/*page" => "pages#show"
  get "/pages/about" => "pages#about"
=======
 
 
  get "/pages/*page" => "pages#show"
>>>>>>> b25250963049d2b8a7ad9d2ac7d4b109abd029c2
  
  root "pages#show", page: "home"
  
end
