class Usergame1 < ActiveRecord::Base
end
