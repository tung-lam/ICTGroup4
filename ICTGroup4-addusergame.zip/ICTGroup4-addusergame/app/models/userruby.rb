class Userruby < ActiveRecord::Base
end
