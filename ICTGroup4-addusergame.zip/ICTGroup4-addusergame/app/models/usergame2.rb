class Usergame2 < ActiveRecord::Base
end
