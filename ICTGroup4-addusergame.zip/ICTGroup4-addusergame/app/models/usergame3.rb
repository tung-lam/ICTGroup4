class Usergame3 < ActiveRecord::Base
end
