class Game1Controller < ApplicationController
	def index
	end
end
