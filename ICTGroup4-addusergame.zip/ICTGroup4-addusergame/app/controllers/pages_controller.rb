class PagesController < ApplicationController
	def show
		render template: "pages/#{params[:page]}"
	end
	
<<<<<<< HEAD
	def about
	end
=======
>>>>>>> b25250963049d2b8a7ad9d2ac7d4b109abd029c2
	
end
